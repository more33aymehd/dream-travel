
<?php

final class ClientController
{
    /**
     * Afficher la liste des clients.
     */
    public static function index(PDO $pdo): void
    {
        Access::requirePermission('client.view');

        $search = trim($_GET['q'] ?? '');

        if ($search !== '') {
    $stmt = $pdo->prepare(
        "SELECT * FROM client
         WHERE nom LIKE :nom
            OR prenom LIKE :prenom
            OR telephone LIKE :telephone
            OR id_client LIKE :id
         ORDER BY nom, prenom"
    );

    $term = "%$search%";

    $stmt->execute([
        'nom' => $term,
        'prenom' => $term,
        'telephone' => $term,
        'id' => $term,
    ]);
} else {
            $stmt = $pdo->query(
                "SELECT * FROM client ORDER BY date_creation DESC"
            );
        }

        $clients = $stmt->fetchAll();

        require dirname(__DIR__, 2) . '/templates/clients/index.php';
    }

    /**
     * Afficher le formulaire de création.
     */
    public static function create(): void
    {
        Access::requirePermission('client.create');

        $csrfToken = Csrf::token();

        require dirname(__DIR__, 2) . '/templates/clients/create.php';
    }

    /**
     * Enregistrer un nouveau client.
     */
    public static function store(PDO $pdo): void
    {
        Access::requirePermission('client.create');
        Request::verifyCsrf();

        $nom = strtoupper(trim($_POST['nom'] ?? ''));
        $prenom = trim($_POST['prenom'] ?? '');
        $telephone = trim($_POST['telephone'] ?? '');
        $typePiece = $_POST['type_piece_identite'] ?? '';
        $numeroPiece = trim($_POST['numero_piece_identite'] ?? '');

        if ($nom === '' || $prenom === '' || $telephone === '') {
            http_response_code(422);
            exit('422 - Nom, prénom et téléphone obligatoires.');
        }

        $typesAutorises = ['CNI', 'PASSEPORT', 'PERMIS', 'CARTE SEJOUR'];

        if ($typePiece !== '' && !in_array($typePiece, $typesAutorises, true)) {
            http_response_code(422);
            exit('422 - Type de pièce invalide.');
        }

        if (($typePiece === '') !== ($numeroPiece === '')) {
            http_response_code(422);
            exit('422 - Le type et le numéro de pièce doivent être renseignés ensemble.');
        }

        do {
            $idClient = 'CLI-' . strtoupper(bin2hex(random_bytes(2)));

            $check = $pdo->prepare(
                'SELECT COUNT(*) FROM client WHERE id_client = ?'
            );
            $check->execute([$idClient]);
        } while ((int) $check->fetchColumn() > 0);

        try {
            $stmt = $pdo->prepare(
                "INSERT INTO client (
                    id_client, nom, prenom, telephone,
                    type_piece_identite, numero_piece_identite,
                    date_creation
                ) VALUES (
                    :id, :nom, :prenom, :telephone,
                    :type_piece, :numero_piece, CURDATE()
                )"
            );

            $stmt->execute([
                'id' => $idClient,
                'nom' => $nom,
                'prenom' => $prenom,
                'telephone' => $telephone,
                'type_piece' => $typePiece !== '' ? $typePiece : null,
                'numero_piece' => $numeroPiece !== '' ? $numeroPiece : null,
            ]);
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                http_response_code(409);
                exit('409 - Cette pièce d’identité est déjà enregistrée.');
            }

            throw $e;
        }

        header('Location: /clients');
        exit;
    }
}
