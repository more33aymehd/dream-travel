<?php

require_once __DIR__ . '/../config/bootstrap.php';

$pdo = Database::connect();

$router = new Router();

$router->get('/', function () use ($pdo) {
    if (!Auth::check()) {
        header('Location: /login');
        exit;
    }

    HomeController::index($pdo);
});
$router->get('/login', function () {
    LoginController::show();
});

$router->post('/login', function () use ($pdo) {
    LoginController::authenticate($pdo);
});
$router->post('/logout', function () {
    LoginController::logout();
});
$router->dispatch(
    $_SERVER['REQUEST_METHOD'] ?? 'GET',
    $_SERVER['REQUEST_URI'] ?? '/'
);